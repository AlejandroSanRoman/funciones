def cambiar_caso(texto):
    texto_cambiado = texto.swapcase()
    return texto_cambiado
texto_original = "monterrey>>>TitEreS"
texto_modificado = cambiar_caso(texto_original)
print(texto_modificado) 
