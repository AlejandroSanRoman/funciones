def perimetro_rectangulo(largo, ancho):
    perimetro = 2 * (largo + ancho)
    return perimetro

largo_rectangulo = 7
ancho_rectangulo = 16
resultado = perimetro_rectangulo(largo_rectangulo, ancho_rectangulo)
print(f"El perimetro del rectanguol con largo {largo_rectangulo} y ancho {ancho_rectangulo} es {resultado}")
