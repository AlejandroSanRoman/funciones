def calcular_temperatura_media(max_temp, min_temp):
    """
    calcula la temperatura media a partir de la temperatura máxima y mínima"""
    return (max_temp + min_temp) / 2

def main():
    num_dias = int(input("introduce el número de días: "))
    
    if num_dias <= 0:
        print('el numero de días debe ser positivo')
        return
    
    for i in range(num_dias):
        print(f"\nDía {i + 1}:")
        max_temp = float(input('Introduce la temperatura maxima: '))
        min_temp = float(input("Introduce la temperatura mínima: "))
        
        temperatura_media = calcular_temperatura_media(max_temp, min_temp)
        
        print(f"la temperatura media del día {i + 1} es {temperatura_media:.2f}°C")

if __name__ == "__main__":
    main()