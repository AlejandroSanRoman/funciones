def millas_a_kilometros(millas):
    factor_conversion = 1.60934

    kilometros = millas * factor_conversion
    return kilometros

millas_distancia = 37
kilometros = millas_a_kilometros(millas_distancia)
print(f'{millas_distancia} millas son {kilometros:.2f} kilómetros')