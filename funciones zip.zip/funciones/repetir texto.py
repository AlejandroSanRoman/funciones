def repetir_texto(texto, veces):
    texto_repetido = texto * veces
    return texto_repetido

texto = 'monterrey!! '
veces = 3
resultado = repetir_texto(texto, veces)
print(resultado)