def multiplicar(a, b):
    producto = a * b
    return producto
numero1 = 6
numero2 = 700
resultado = multiplicar(numero1, numero2)
print(f"el resultado ode {numero1} y {numero2} es {resultado}")