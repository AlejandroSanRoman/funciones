import math

def area_circulo(radio):
    area = math.pi * (radio ** 2)
    return area

radio_circulo = 869
area = area_circulo(radio_circulo)
print(f"El área del círculo con radio {radio_circulo} es {area:.2f}")
