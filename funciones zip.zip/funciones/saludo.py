def saludar(nombre):
    return f"Hola, {nombre}"

nombre_usuario = "Moisés"
saludo = saludar(nombre_usuario)
print(saludo)
